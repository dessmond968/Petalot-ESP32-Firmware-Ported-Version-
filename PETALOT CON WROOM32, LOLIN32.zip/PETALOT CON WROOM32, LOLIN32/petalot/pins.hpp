#define PIN_EN       14
#define PIN_STEP     26
#define PIN_DIR      27
#define PIN_HEATER   25
#define PIN_FILAMENT 33
#define LED_BUILTIN 2
#define PIN_THERMISTOR 34